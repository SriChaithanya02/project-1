 
	
<div class="container">

<p style="width: auto;">Welcome to Online Job Portal. It Provides facility to the Job seeker to search for Various jobs as per his qualification. Here Job Seeker can registered himself on the web Portal and create his profile along with his educational information. Job
	Seeker can search various jobs and apply for the job according to their qualification. This Portal is also designed for the various employer who required to recruit the employees to their Organization. Employer can registered himselfon the web portal and they can Upload information of various job Vacancies in their Organization.
</p>
</div> 

	
								  	
		   <!-- Form itself -->
	<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4">
        <div class="widget">
          <h5 class="widgetheading">Our Contact</h5>
          <address>
          <strong>Our Company</strong><br>
          ONLINE JOB PORTAL<br>
           Pin-21542  HITEC CITY.</address>
          <p>
            <i class="icon-phone"></i> 9912643637 <br>
            <i class="icon-envelope-alt"></i> onlinejobportal@gmail.com
          </p>
        </div>
      </div> 
</footer>
 