 

<br>
<div class="container">

<p style="width: auto;">Welcome to Online Job Portal. It Provides facility to the Job seeker to search for Various jobs as per his qualification. Here Job Seeker can registered himself on the web Portal and create his profile along with his educational information. Job
	Seeker can search various jobs and apply for the job according to their qualification. This Portal is also designed for the various employer who required to recruit the employees to their Organization. Employer can registered himselfon the
	web portal and they can Upload information of various job Vacancies in their Organization.
</p>
</div> 
